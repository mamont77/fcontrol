#SKD101|fcontrol|7|2013.03.31 15:43:20|77|7|6|10|40|5|3|6

DROP TABLE IF EXISTS `album`;
CREATE TABLE `album` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `artist` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `album` VALUES
(2, 'привет234', 'медвед234'),
(3, 'привет пок', 'пока'),
(4, 'test', 'test'),
(6, 'sdf', 'sdfs'),
(7, 'gh', 'fgh'),
(8, 'тест', 'тестик2'),
(10, 'fu', 'fru');

DROP TABLE IF EXISTS `library_airport`;
CREATE TABLE `library_airport` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `country` int(10) DEFAULT NULL,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT 'name of airport',
  `short_name` varchar(30) NOT NULL DEFAULT '',
  `code_icao` varchar(4) NOT NULL DEFAULT '',
  `code_iata` varchar(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_airport` VALUES
(4, 10, '223333333333333', '23333333333333333333', '1234', '234'),
(5, 10, '2345235234', '235421354', '2355', '523'),
(6, 2, '234', '21342134', '3242', '23q'),
(7, 2, '235432qq5', '2352', '5443', '234'),
(8, 2, 'q34q56432r543', '345tr4r', '345r', 'wq4'),
(9, 2, 'twetrawer6e57', 'tawetwaet', 'twer', 'ert');

DROP TABLE IF EXISTS `library_country`;
CREATE TABLE `library_country` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `region` int(10) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `code` varchar(3) DEFAULT NULL COMMENT 'code of country',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=12 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_country` VALUES
(1, 1, 'test', 'aa'),
(2, 12, '1ertsrtr', '119'),
(3, 3, '2232', '222'),
(4, 1, '4352345', '345'),
(5, 1, '1112', '112'),
(6, 1, 'екнкн', 'tyr'),
(7, 1, '365456', '447'),
(8, 1, 'ryt', 'ry'),
(10, 5, '3456345634', '346'),
(11, 6, '123', '123');

DROP TABLE IF EXISTS `library_region`;
CREATE TABLE `library_region` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT 'Region of the world',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=47 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_region` VALUES
(6, 'sdfgsdg'),
(2, '444'),
(18, '345235'),
(4, '777'),
(5, 'tyuyutu'),
(7, 'fth'),
(8, 'yutu'),
(9, '987'),
(17, '456'),
(37, 'yutruytyu'),
(12, '11155'),
(13, '345'),
(14, 'tyty'),
(43, 'ertewrt'),
(19, 'wet'),
(20, '57w4574567'),
(21, 'erteartyerst'),
(22, 'sfaZsdf'),
(23, 'sdfsa'),
(24, 'sdfs'),
(25, 'asfdasf'),
(26, 'mnb'),
(27, 'dsf'),
(28, 'вапывап'),
(29, 'укафуае'),
(30, '111sgfsdg'),
(31, 'варр'),
(32, '527'),
(33, 'esf'),
(34, '5y67we5yry'),
(35, 'енр'),
(36, 'rfgrsd'),
(38, '```'),
(39, '666'),
(40, '1112567uy'),
(41, '1116787'),
(42, '111rtrt'),
(44, '111'),
(45, '32142134'),
(46, 'etyeryt');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `display_name` varchar(50) DEFAULT NULL,
  `password` varchar(128) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=58 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `user` VALUES
(1, 'ОТМОРОЖЕННЫЙ МАМОНТ', 'ruslan.piskarev@gmail.com', NULL, '$2y$14$OaNgN6Zlnw/NDmVEkJdKlOzQxvGiJNBMfYfuwP7/c1Httjnu5TnJ6', 1),
(53, 'Крамаренко Владислав', 'vlad@examle.com', NULL, '$2y$14$yFW7Of3yRT5NVTK8sWaMhONRQZtdRBWoftay2SnzP.qZPmUvWgxj.', 1),
(54, 'test test', 'sdfsdfsd@sdfgsdf.com', NULL, '$2y$14$7lLQU/oDoReGOK1a/0Ou4Oq5hPo8VjpWhuxep4R6WIPqPGscg.4WW', 1),
(56, '456456456346532456', '456465@ertert.com', NULL, '$2y$14$Wv1rgyacLixWKjeb9o2PNeeEkVBJf1cMlYBltaR3N4NbsQbSKCIne', 1),
(57, 'erwearwerwer', 'erwerearw@aresre.com', NULL, '$2y$14$wDK7sNWujOzyaSCrLaMsGuHDUl318ALpWlJ6CntrwsqIFRr65MHMa', 1);

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `role_id` varchar(255) NOT NULL,
  `default` tinyint(1) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `user_role` VALUES
('admin', 0, 'user'),
('guest', 1, NULL),
('user', 0, NULL);

DROP TABLE IF EXISTS `user_role_linker`;
CREATE TABLE `user_role_linker` (
  `user_id` int(11) unsigned NOT NULL,
  `role_id` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `user_role_linker` VALUES
(1, 'admin'),
(52, 'admin'),
(53, 'admin'),
(56, 'manager'),
(57, 'manager'),
(54, 'user');

