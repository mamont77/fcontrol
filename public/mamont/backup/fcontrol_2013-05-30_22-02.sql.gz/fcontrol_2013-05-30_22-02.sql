#SKD101|fcontrol|15|2013.05.30 22:02:57|195|9|13|4|5|4|10|16|4|2|112|2|5|3|6

DROP TABLE IF EXISTS `album`;
CREATE TABLE `album` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `artist` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `album` VALUES
(2, 'привет234', 'медвед234'),
(3, 'привет пок', 'пока'),
(4, 'test', 'test'),
(6, 'sdf', 'sdfs'),
(7, 'gh', 'fgh'),
(8, 'тест', 'тестик2'),
(10, 'fu', 'fru'),
(13, 'szdfsdf', 'fdsf'),
(14, 'fdsgdsgh', 'xfg');

DROP TABLE IF EXISTS `flightBaseForm`;
CREATE TABLE `flightBaseForm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refNumberOrder` varchar(16) NOT NULL DEFAULT '',
  `dateOrder` int(10) DEFAULT NULL,
  `kontragent` int(11) DEFAULT NULL,
  `airOperator` int(11) DEFAULT NULL,
  `aircraft` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `refNumberOrder` (`refNumberOrder`)
) ENGINE=MyISAM AUTO_INCREMENT=22 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `flightBaseForm` VALUES
(8, 'ORD-2013052248/1', 2013, 2, 5, '12345'),
(9, 'ORD-2013052204/1', 2013, 3, 4, '12345'),
(10, 'ORD-2013052207/1', 2013, 3, 4, '2132132456'),
(12, 'ORD-2013052243/1', 2013, 2, 1, '123'),
(13, 'ORD-2013052322/1', 2013, 2, 3, '2132132456'),
(14, 'ORD-2013052914/1', 2008, 3, 1, '2132132456'),
(15, 'ORD-2013052940/1', 2013, 3, 3, '1000000000'),
(16, 'ORD-10/03/14/00', NULL, 2, 3, '1000000000'),
(17, 'ORD-10/03/19/00', NULL, 2, 3, '2132132456'),
(18, 'ORD-19700101/00', NULL, 3, 4, '123'),
(19, 'ORD-700101/00', NULL, 2, 3, '123'),
(20, 'ORD-870518/00', 548280000, 2, 1, '2132132456'),
(21, 'ORD-141003/00', 1412283600, 2, 4, '2132132456');

DROP TABLE IF EXISTS `library_air_operator`;
CREATE TABLE `library_air_operator` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `short_name` varchar(15) DEFAULT NULL,
  `code_icao` varchar(3) NOT NULL DEFAULT '',
  `code_iata` varchar(2) NOT NULL DEFAULT '',
  `country` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `shot_name` (`short_name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_air_operator` VALUES
(1, 'кпыуп', 'кпфыукпу', '1ку', '2у', 11),
(3, 'вапвап', 'апвап', 'вап', '', 12),
(4, 'укецфе', 'кекуе', 'куе', 'ке', 12),
(5, 'Name of Air Operator', 'Short name of A', 'ICA', 'IA', 11);

DROP TABLE IF EXISTS `library_aircraft`;
CREATE TABLE `library_aircraft` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aircraft_type` int(10) DEFAULT NULL,
  `reg_number` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reg_number` (`reg_number`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_aircraft` VALUES
(2, 4, '222'),
(6, 2, '2132132456'),
(3, 2, '1000000000'),
(4, 7, '123'),
(5, 10, '12345');

DROP TABLE IF EXISTS `library_aircraft_type`;
CREATE TABLE `library_aircraft_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_aircraft_type` VALUES
(7, 'vxzcvxc'),
(2, 'szgsdgsdfd'),
(8, 'xcvxcvv'),
(10, 'ваВа');

DROP TABLE IF EXISTS `library_airport`;
CREATE TABLE `library_airport` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `country` int(10) DEFAULT NULL,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT 'name of airport',
  `short_name` varchar(30) NOT NULL DEFAULT '',
  `code_icao` varchar(4) NOT NULL DEFAULT '',
  `code_iata` varchar(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_airport` VALUES
(4, 10, '223333333333333', '23333333333333333333', '1234', '234'),
(10, 11, 'Борисполь', 'МАО', '0100', '123'),
(5, 10, '2345235234', '235421354', '2355', '523'),
(6, 2, '234', '21342134', '3242', '23q'),
(7, 2, '235432qq5', '2352', '5443', '234'),
(9, 2, 'twetrawer6e57', 'tawetwaet', 'twer', 'ert'),
(13, 0, 'sdfgsd', 'sdg', 'sdfz', 'szd'),
(12, 11, 'Жуляны', 'МАО2', '0101', '111'),
(14, 10, 'rszg', 'szdgzsdg', 'SDGS', 'SGd'),
(15, 12, 'aewtrawerf', 'werwaer', 'wear', 'wae');

DROP TABLE IF EXISTS `library_country`;
CREATE TABLE `library_country` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `region` int(10) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `code` varchar(3) DEFAULT NULL COMMENT 'code of country',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=19 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_country` VALUES
(1, 1, 'test', 'aa'),
(2, 2, 'Россия', 'RU'),
(3, 3, '2232', '222'),
(4, 1, '4352345', '345'),
(5, 1, '1112', '112'),
(6, 1, 'екнкн', 'tyr'),
(7, 1, '365456', '447'),
(8, 1, 'ryt', 'ry'),
(18, 6, 'вавыфав', 'das'),
(11, 66, 'Украина', 'UA'),
(12, 6, 'уФУАУ', 'sdf'),
(13, 17, 'sefAWEfAE', 'ASF'),
(14, 5, 'sfsafSDAf', 'SZD'),
(15, 5, 'asdsd', 'aSd'),
(16, 13, 'ASDDaSd', '354'),
(17, 4, 'sytysty', 'trs');

DROP TABLE IF EXISTS `library_currency`;
CREATE TABLE `library_currency` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `currency` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currency` (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_currency` VALUES
(3, '1112', '122'),
(2, 'sds111', '444'),
(4, 'sadas', 'ыва'),
(5, 'фывафыаываыва', 'ваы');

DROP TABLE IF EXISTS `library_fixed_service_type`;
CREATE TABLE `library_fixed_service_type` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;

DROP TABLE IF EXISTS `library_kontragent`;
CREATE TABLE `library_kontragent` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `short_name` varchar(15) DEFAULT NULL,
  `address` text,
  `phone1` varchar(30) DEFAULT NULL,
  `phone2` varchar(30) DEFAULT NULL,
  `phone3` varchar(30) DEFAULT NULL,
  `fax` varchar(30) DEFAULT NULL,
  `mail` varchar(30) DEFAULT NULL,
  `sita` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `short_name` (`short_name`),
  UNIQUE KEY `mail` (`mail`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_kontragent` VALUES
(2, 'fasdffgs', '1115465', 'ertrtsdfsa', 'ertewrtsdfsaf', 'ertewrtsadf', 'eretr', 'ertewrtsdf', 'sdferter@dsfsdf.com', 'er'),
(3, 'qwewq', 'qwewqe', 'rqer\r\nweqe', 'wqeqwe', 'qweqwe', 'qwee', 'wqeqw', 'wqeqw@sdafedf.com', 'wewe');

DROP TABLE IF EXISTS `library_region`;
CREATE TABLE `library_region` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT 'Region of the world',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=123 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_region` VALUES
(6, 'sdfgsdg'),
(2, '444'),
(18, '345235'),
(4, '777'),
(5, 'tyuyutu'),
(7, 'fth'),
(8, 'yutu'),
(9, '987'),
(17, '456'),
(37, 'yutruytyu'),
(12, 'SDGDGSDG'),
(13, '345'),
(14, 'tyty'),
(43, 'ertewrt'),
(19, 'wet'),
(20, '57w4574567'),
(21, 'erteartyerst'),
(22, 'sfaZsdf'),
(23, 'sdfsa'),
(24, 'sdfs'),
(25, 'asfdasf'),
(26, 'mnb'),
(27, 'dsf'),
(28, 'вапывап'),
(29, 'укафуае'),
(30, '111sgfsdg'),
(31, 'варр'),
(32, '527'),
(33, 'esf'),
(34, '5y67we5yry'),
(35, 'енр'),
(36, 'rfgrsd'),
(38, '```'),
(39, '666'),
(40, '4w5763q47'),
(41, '1116787rtserg__65667e7'),
(42, '111sfasefda'),
(44, 'sadfASFASFd'),
(45, '32142134'),
(46, 'etyeryt'),
(47, 'xfdgbsf'),
(48, 'saff'),
(49, 'gf'),
(50, 'erte'),
(51, '1116uytu'),
(52, '65465'),
(60, '123'),
(54, '11156465про'),
(55, '4w56w4356'),
(56, 'fgbdxfgdg'),
(57, 'sdfgzsdfg'),
(58, '111xvgxcv'),
(59, '111dfsfdsf'),
(61, '111654465'),
(62, '111sdfsd'),
(63, '45465465'),
(66, 'SAfAS'),
(65, 'sfsdf'),
(67, '674567'),
(68, 'tsrtsret'),
(69, '111xfbcf'),
(114, 'erter'),
(71, '11'),
(72, 'tyudrt'),
(73, '11165446544654'),
(74, 'кенкенкен'),
(75, 'atrwet'),
(76, 'srgszdg'),
(77, 'thydsfth'),
(78, 'sfgASDF'),
(79, 'eyraery'),
(80, '111dhgzdfhgfxzbg'),
(81, 'ghrfhgdf'),
(82, 'dgfsdgd'),
(83, 'etawertewrt'),
(84, 'rgsrg'),
(85, 'dfSADGf'),
(86, 'dgSG'),
(87, 'sgfdsg'),
(88, 'gzdfgdfgdfg'),
(89, 'sdfszdf'),
(90, 'sfdsdf'),
(91, 'sfgsdf'),
(92, 'sgfaszxcvzxc'),
(93, 'zvxzxvc'),
(94, '111dff'),
(95, 'rtyseryterdfgf'),
(96, 'gffdg'),
(97, '111gsdfg'),
(98, 'sdfgsdfdf'),
(113, '111rtert'),
(100, 'dgsadgfsdfg'),
(101, '222'),
(102, '111dfgfgf'),
(103, 'fsdf'),
(104, 'sgfsdggh'),
(105, 'sdfsdfdfsdfsdf'),
(106, '111'),
(107, 'ertert'),
(108, '879089589'),
(109, 'укенуыкеке'),
(110, 'врвар'),
(111, 'кенкенкен8'),
(112, 'цЦЙУВЫФВЫФ'),
(115, 'ryserysery'),
(116, 'dsrgdsfg'),
(117, 'urut6rt'),
(118, 'zfdgsdfg'),
(119, 'urtyry'),
(120, 'ваа'),
(121, 'sadfdsaf'),
(122, 'asdf');

DROP TABLE IF EXISTS `library_unit`;
CREATE TABLE `library_unit` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `library_unit` VALUES
(2, '1112'),
(3, '111');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `display_name` varchar(50) DEFAULT NULL,
  `password` varchar(128) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=58 /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `user` VALUES
(1, 'ОТМОРОЖЕННЫЙ МАМОНТ', 'ruslan.piskarev@gmail.com', NULL, '$2y$14$OaNgN6Zlnw/NDmVEkJdKlOzQxvGiJNBMfYfuwP7/c1Httjnu5TnJ6', 1),
(53, 'Крамаренко Владислав', 'kramarenko_vladislav@ukr.net', NULL, '$2y$14$wqnE0s6qg7LIDGgGCYNgROkX42ZZAduk.J02VCDh65H0Ua4ab0Vv.', 1),
(54, 'test test', 'sdfsdfsd@sdfgsdf.com', NULL, '$2y$14$7lLQU/oDoReGOK1a/0Ou4Oq5hPo8VjpWhuxep4R6WIPqPGscg.4WW', 1),
(56, '456456456346532456', '456465@ertert.com', NULL, '$2y$14$Wv1rgyacLixWKjeb9o2PNeeEkVBJf1cMlYBltaR3N4NbsQbSKCIne', 1),
(57, 'erwearwerwer', 'erwerearw@aresre.com', NULL, '$2y$14$wDK7sNWujOzyaSCrLaMsGuHDUl318ALpWlJ6CntrwsqIFRr65MHMa', 1);

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `role_id` varchar(255) NOT NULL,
  `default` tinyint(1) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `user_role` VALUES
('admin', 0, 'user'),
('guest', 1, NULL),
('user', 0, NULL);

DROP TABLE IF EXISTS `user_role_linker`;
CREATE TABLE `user_role_linker` (
  `user_id` int(11) unsigned NOT NULL,
  `role_id` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;

INSERT INTO `user_role_linker` VALUES
(1, 'admin'),
(52, 'admin'),
(53, 'admin'),
(56, 'manager'),
(57, 'manager'),
(54, 'user');

